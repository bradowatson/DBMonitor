﻿using System;
using System.Net.Sockets;

/// 
/// <summary>
/// @author Brad Watson
/// </summary>
namespace DBMonitor
{

    public class WilyMetricReporter
    {

        internal string metricName;
        internal int val;
        internal long value;
        internal bool success;

        public WilyMetricReporter(string metricName, int val)
        {
            Console.WriteLine("<metric type=\"LongCounter\" name=\"" + metricName + "\" value=\"" + val + "\"/>");
        }

        public WilyMetricReporter(string metricName, bool success)
        {
            if (success)
            {
                val = 1;
            }
            else
            {
                val = 0;
            }
            Console.WriteLine("<metric type=\"LongCounter\" name=\"" + metricName + "\" value=\"" + val + "\"/>");
        }

        public WilyMetricReporter(string metricName, string val)
        {
            Console.WriteLine("<metric type=\"LongCounter\" name=\"" + metricName + "\" value=\"" + val + "\"/>");
        }

        public WilyMetricReporter(string metricName, long val)
        {
            Console.WriteLine("<metric type=\"LongCounter\" name=\"" + metricName + "\" value=\"" + val + "\"/>");
        }

        public static void reportMetrics(string metricName, int val)
        {
            Console.WriteLine("<metric type=\"LongCounter\" name=\"" + metricName + "\" value=\"" + val + "\"/>");
        }

        public static void reportMetrics(string metricName, long val)
        {
            Console.WriteLine("<metric type=\"LongCounter\" name=\"" + metricName + "\" value=\"" + val + "\"/>");
        }

        public virtual string MetricName { get; set; }


        public virtual int Val { get; set; }


        public virtual long Value { get; set; }

    }

}