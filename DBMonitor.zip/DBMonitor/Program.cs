﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Data.Odbc;
using System.Diagnostics;

namespace DBMonitor
{
	class Program
	{
		static void Main(string[] args)
		{
            bool exists = true;
            int x = 0;
            while(exists)
            {
                var applicationSettings = ConfigurationManager.GetSection("Queries/Query." + x) as NameValueCollection;
                if (applicationSettings == null)
                {
                    exists = false;
                }
                else
                {
                    try
                    {
                        using (OdbcConnection con = new OdbcConnection(applicationSettings["ConnectionString"]))
                        {
                            Stopwatch stopwatch = Stopwatch.StartNew();
                            con.Open();
                            using (OdbcCommand com = new OdbcCommand(applicationSettings["Query"], con))
                            {
                                using (OdbcDataReader reader = com.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        string result = reader.GetString(0);
                                        stopwatch.Stop();
                                        string path = applicationSettings["MetricTree"] + "|" + applicationSettings["MetricName"] + ":";
                                        new WilyMetricReporter(path + "Result", result);
                                        new WilyMetricReporter(path + "Time", stopwatch.ElapsedMilliseconds);
                                        new WilyMetricReporter(path + "Success", 1);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        new WilyMetricReporter(applicationSettings["MetricTree"] + "|" + applicationSettings["MetricName"] + ":Success", 0);
                        throw;
                    }
                }
            x++;
            }
        }
    }
}